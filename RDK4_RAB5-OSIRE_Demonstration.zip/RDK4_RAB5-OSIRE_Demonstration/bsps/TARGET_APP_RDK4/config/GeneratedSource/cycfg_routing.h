/*******************************************************************************
 * File Name: cycfg_routing.h
 *
 * Description:
 * Establishes all necessary connections between hardware elements.
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.20.0
 * device-db 4.16.0.6098
 * mtb-pdl-cat2 2.11.0.12518
 *
 *******************************************************************************
 * Copyright 2024 Cypress Semiconductor Corporation (an Infineon company) or
 * an affiliate of Cypress Semiconductor Corporation.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_ROUTING_H)
#define CYCFG_ROUTING_H

#include "cycfg_notices.h"

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#define ioss_0_port_0_pin_6_ANALOG P0_6_SRSS_ADFT_POR_PAD_HV
#define ioss_0_port_0_pin_7_ANALOG P0_7_EXCO_ECO_OUT
#define ioss_0_port_1_pin_0_HSIOM P1_0_SCB0_UART_RX
#define ioss_0_port_1_pin_1_HSIOM P1_1_SCB0_UART_TX
#define ioss_0_port_2_pin_2_HSIOM P2_2_SCB1_SPI_CLK
#define ioss_0_port_2_pin_3_HSIOM P2_3_SCB1_SPI_SELECT0
#define ioss_0_port_3_pin_0_HSIOM P3_0_SCB1_SPI_MOSI
#define ioss_0_port_3_pin_2_HSIOM P3_2_CPUSS_SWD_DATA
#define ioss_0_port_3_pin_3_HSIOM P3_3_CPUSS_SWD_CLK
#define ioss_0_port_5_pin_1_ANALOG P5_1_MSC1_CMOD1PADS
#define ioss_0_port_5_pin_2_ANALOG P5_2_MSC1_CMOD2PADS
#define ioss_0_port_5_pin_3_ANALOG P5_3_MSC1_S_PAD13
#define ioss_0_port_5_pin_5_ANALOG P5_5_MSC1_S_PAD15
#define ioss_0_port_5_pin_6_ANALOG P5_6_MSC1_S_PAD0
#define ioss_0_port_8_pin_0_HSIOM P8_0_SCB3_SPI_MOSI
#define ioss_0_port_8_pin_1_HSIOM P8_1_SCB3_SPI_MISO
#define ioss_0_port_8_pin_2_HSIOM P8_2_SCB3_SPI_CLK
#define ioss_0_port_8_pin_3_HSIOM P8_3_SCB3_SPI_SELECT0
#define MSC1_CMOD1 1
#define MSC1_CMOD2 2
#define MSC1_SPAD0 0
#define MSC1_SPAD1 13
#define MSC1_SPAD2 15

static inline void init_cycfg_routing(void) {}

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_ROUTING_H */
