/*******************************************************************************
 * File Name: cycfg_pins.h
 *
 * Description:
 * Pin configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.20.0
 * device-db 4.16.0.6098
 * mtb-pdl-cat2 2.11.0.12518
 *
 *******************************************************************************
 * Copyright 2024 Cypress Semiconductor Corporation (an Infineon company) or
 * an affiliate of Cypress Semiconductor Corporation.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_PINS_H)
#define CYCFG_PINS_H

#include "cycfg_notices.h"
#include "cy_gpio.h"
#include "cycfg_routing.h"

#if defined (CY_USING_HAL)
#include "cyhal_hwmgr.h"
#endif /* defined (CY_USING_HAL) */

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#if defined (CY_USING_HAL)
#define I2C_SCL (P0_0)
#define CYBSP_I2C_SCL I2C_SCL
#define I2C_SDA (P0_1)
#define CYBSP_I2C_SDA I2C_SDA
#define CANFD_RX (P0_2)
#define CANFD_TX (P0_3)
#endif /* defined (CY_USING_HAL) */

#define WCO_IN_ENABLED 1U
#define WCO_IN_PORT GPIO_PRT0
#define WCO_IN_PORT_NUM 0U
#define WCO_IN_PIN 4U
#define WCO_IN_NUM 4U
#define WCO_IN_DRIVEMODE CY_GPIO_DM_ANALOG
#define WCO_IN_INIT_DRIVESTATE 1
#ifndef ioss_0_port_0_pin_4_HSIOM
    #define ioss_0_port_0_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define WCO_IN_HSIOM ioss_0_port_0_pin_4_HSIOM
#define WCO_IN_IRQ ioss_interrupts_gpio_0_IRQn

#if defined (CY_USING_HAL)
#define WCO_IN_HAL_PORT_PIN P0_4
#define WCO_IN P0_4
#define WCO_IN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define WCO_IN_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define WCO_IN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define WCO_OUT_ENABLED 1U
#define WCO_OUT_PORT GPIO_PRT0
#define WCO_OUT_PORT_NUM 0U
#define WCO_OUT_PIN 5U
#define WCO_OUT_NUM 5U
#define WCO_OUT_DRIVEMODE CY_GPIO_DM_ANALOG
#define WCO_OUT_INIT_DRIVESTATE 1
#ifndef ioss_0_port_0_pin_5_HSIOM
    #define ioss_0_port_0_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define WCO_OUT_HSIOM ioss_0_port_0_pin_5_HSIOM
#define WCO_OUT_IRQ ioss_interrupts_gpio_0_IRQn

#if defined (CY_USING_HAL)
#define WCO_OUT_HAL_PORT_PIN P0_5
#define WCO_OUT P0_5
#define WCO_OUT_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define WCO_OUT_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define WCO_OUT_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define ECO_IN_ENABLED 1U
#define ECO_IN_PORT GPIO_PRT0
#define ECO_IN_PORT_NUM 0U
#define ECO_IN_PIN 6U
#define ECO_IN_NUM 6U
#define ECO_IN_DRIVEMODE CY_GPIO_DM_ANALOG
#define ECO_IN_INIT_DRIVESTATE 1
#ifndef ioss_0_port_0_pin_6_HSIOM
    #define ioss_0_port_0_pin_6_HSIOM HSIOM_SEL_GPIO
#endif
#define ECO_IN_HSIOM ioss_0_port_0_pin_6_HSIOM
#define ECO_IN_IRQ ioss_interrupts_gpio_0_IRQn

#if defined (CY_USING_HAL)
#define ECO_IN_HAL_PORT_PIN P0_6
#define ECO_IN P0_6
#define ECO_IN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ECO_IN_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define ECO_IN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define ECO_OUT_ENABLED 1U
#define ECO_OUT_PORT GPIO_PRT0
#define ECO_OUT_PORT_NUM 0U
#define ECO_OUT_PIN 7U
#define ECO_OUT_NUM 7U
#define ECO_OUT_DRIVEMODE CY_GPIO_DM_ANALOG
#define ECO_OUT_INIT_DRIVESTATE 1
#ifndef ioss_0_port_0_pin_7_HSIOM
    #define ioss_0_port_0_pin_7_HSIOM HSIOM_SEL_GPIO
#endif
#define ECO_OUT_HSIOM ioss_0_port_0_pin_7_HSIOM
#define ECO_OUT_IRQ ioss_interrupts_gpio_0_IRQn

#if defined (CY_USING_HAL)
#define ECO_OUT_HAL_PORT_PIN P0_7
#define ECO_OUT P0_7
#define ECO_OUT_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ECO_OUT_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define ECO_OUT_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#define CYBSP_LIN_RX (P11_0)
#define CYBSP_LIN_TX (P11_1)
#define ARD_IO3 (P11_2)
#define ARD_IO4 (P11_3)
#define ARD_IO5 (P11_4)
#define ARD_IO6 (P11_5)
#define SPI_CS3 (P12_0)
#define ARD_IO8 (P12_1)
#endif /* defined (CY_USING_HAL) */

#define KITPROG_RX_ENABLED 1U
#define CYBSP_DEBUG_UART_RX_ENABLED KITPROG_RX_ENABLED
#define KITPROG_RX_PORT GPIO_PRT1
#define CYBSP_DEBUG_UART_RX_PORT KITPROG_RX_PORT
#define KITPROG_RX_PORT_NUM 1U
#define CYBSP_DEBUG_UART_RX_PORT_NUM KITPROG_RX_PORT_NUM
#define KITPROG_RX_PIN 0U
#define CYBSP_DEBUG_UART_RX_PIN KITPROG_RX_PIN
#define KITPROG_RX_NUM 0U
#define CYBSP_DEBUG_UART_RX_NUM KITPROG_RX_NUM
#define KITPROG_RX_DRIVEMODE CY_GPIO_DM_HIGHZ
#define CYBSP_DEBUG_UART_RX_DRIVEMODE KITPROG_RX_DRIVEMODE
#define KITPROG_RX_INIT_DRIVESTATE 1
#define CYBSP_DEBUG_UART_RX_INIT_DRIVESTATE KITPROG_RX_INIT_DRIVESTATE
#ifndef ioss_0_port_1_pin_0_HSIOM
    #define ioss_0_port_1_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define KITPROG_RX_HSIOM ioss_0_port_1_pin_0_HSIOM
#define CYBSP_DEBUG_UART_RX_HSIOM KITPROG_RX_HSIOM
#define KITPROG_RX_IRQ ioss_interrupts_gpio_1_IRQn
#define CYBSP_DEBUG_UART_RX_IRQ KITPROG_RX_IRQ

#if defined (CY_USING_HAL)
#define KITPROG_RX_HAL_PORT_PIN P1_0
#define CYBSP_DEBUG_UART_RX_HAL_PORT_PIN KITPROG_RX_HAL_PORT_PIN
#define KITPROG_RX P1_0
#define CYBSP_DEBUG_UART_RX KITPROG_RX
#define KITPROG_RX_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_DEBUG_UART_RX_HAL_IRQ KITPROG_RX_HAL_IRQ
#define KITPROG_RX_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_DEBUG_UART_RX_HAL_DIR KITPROG_RX_HAL_DIR
#define KITPROG_RX_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define CYBSP_DEBUG_UART_RX_HAL_DRIVEMODE KITPROG_RX_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) */

#define KITPROG_TX_ENABLED 1U
#define CYBSP_DEBUG_UART_TX_ENABLED KITPROG_TX_ENABLED
#define KITPROG_TX_PORT GPIO_PRT1
#define CYBSP_DEBUG_UART_TX_PORT KITPROG_TX_PORT
#define KITPROG_TX_PORT_NUM 1U
#define CYBSP_DEBUG_UART_TX_PORT_NUM KITPROG_TX_PORT_NUM
#define KITPROG_TX_PIN 1U
#define CYBSP_DEBUG_UART_TX_PIN KITPROG_TX_PIN
#define KITPROG_TX_NUM 1U
#define CYBSP_DEBUG_UART_TX_NUM KITPROG_TX_NUM
#define KITPROG_TX_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define CYBSP_DEBUG_UART_TX_DRIVEMODE KITPROG_TX_DRIVEMODE
#define KITPROG_TX_INIT_DRIVESTATE 1
#define CYBSP_DEBUG_UART_TX_INIT_DRIVESTATE KITPROG_TX_INIT_DRIVESTATE
#ifndef ioss_0_port_1_pin_1_HSIOM
    #define ioss_0_port_1_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define KITPROG_TX_HSIOM ioss_0_port_1_pin_1_HSIOM
#define CYBSP_DEBUG_UART_TX_HSIOM KITPROG_TX_HSIOM
#define KITPROG_TX_IRQ ioss_interrupts_gpio_1_IRQn
#define CYBSP_DEBUG_UART_TX_IRQ KITPROG_TX_IRQ

#if defined (CY_USING_HAL)
#define KITPROG_TX_HAL_PORT_PIN P1_1
#define CYBSP_DEBUG_UART_TX_HAL_PORT_PIN KITPROG_TX_HAL_PORT_PIN
#define KITPROG_TX P1_1
#define CYBSP_DEBUG_UART_TX KITPROG_TX
#define KITPROG_TX_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_DEBUG_UART_TX_HAL_IRQ KITPROG_TX_HAL_IRQ
#define KITPROG_TX_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define CYBSP_DEBUG_UART_TX_HAL_DIR KITPROG_TX_HAL_DIR
#define KITPROG_TX_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_DEBUG_UART_TX_HAL_DRIVEMODE KITPROG_TX_HAL_DRIVEMODE
#define ARD_ADC1 (P2_0)
#define CYBSP_A0 ARD_ADC1
#define ARD_ADC2 (P2_1)
#define CYBSP_A1 ARD_ADC2
#endif /* defined (CY_USING_HAL) */

#define ARD_ADC3_ENABLED 1U
#define CYBSP_A2_ENABLED ARD_ADC3_ENABLED
#define sSPI_CLK_ENABLED ARD_ADC3_ENABLED
#define ARD_ADC3_PORT GPIO_PRT2
#define CYBSP_A2_PORT ARD_ADC3_PORT
#define sSPI_CLK_PORT ARD_ADC3_PORT
#define ARD_ADC3_PORT_NUM 2U
#define CYBSP_A2_PORT_NUM ARD_ADC3_PORT_NUM
#define sSPI_CLK_PORT_NUM ARD_ADC3_PORT_NUM
#define ARD_ADC3_PIN 2U
#define CYBSP_A2_PIN ARD_ADC3_PIN
#define sSPI_CLK_PIN ARD_ADC3_PIN
#define ARD_ADC3_NUM 2U
#define CYBSP_A2_NUM ARD_ADC3_NUM
#define sSPI_CLK_NUM ARD_ADC3_NUM
#define ARD_ADC3_DRIVEMODE CY_GPIO_DM_HIGHZ
#define CYBSP_A2_DRIVEMODE ARD_ADC3_DRIVEMODE
#define sSPI_CLK_DRIVEMODE ARD_ADC3_DRIVEMODE
#define ARD_ADC3_INIT_DRIVESTATE 1
#define CYBSP_A2_INIT_DRIVESTATE ARD_ADC3_INIT_DRIVESTATE
#define sSPI_CLK_INIT_DRIVESTATE ARD_ADC3_INIT_DRIVESTATE
#ifndef ioss_0_port_2_pin_2_HSIOM
    #define ioss_0_port_2_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_ADC3_HSIOM ioss_0_port_2_pin_2_HSIOM
#define CYBSP_A2_HSIOM ARD_ADC3_HSIOM
#define sSPI_CLK_HSIOM ARD_ADC3_HSIOM
#define ARD_ADC3_IRQ ioss_interrupts_gpio_2_IRQn
#define CYBSP_A2_IRQ ARD_ADC3_IRQ
#define sSPI_CLK_IRQ ARD_ADC3_IRQ

#if defined (CY_USING_HAL)
#define ARD_ADC3_HAL_PORT_PIN P2_2
#define CYBSP_A2_HAL_PORT_PIN ARD_ADC3_HAL_PORT_PIN
#define sSPI_CLK_HAL_PORT_PIN ARD_ADC3_HAL_PORT_PIN
#define ARD_ADC3 P2_2
#define CYBSP_A2 ARD_ADC3
#define sSPI_CLK ARD_ADC3
#define ARD_ADC3_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_A2_HAL_IRQ ARD_ADC3_HAL_IRQ
#define sSPI_CLK_HAL_IRQ ARD_ADC3_HAL_IRQ
#define ARD_ADC3_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_A2_HAL_DIR ARD_ADC3_HAL_DIR
#define sSPI_CLK_HAL_DIR ARD_ADC3_HAL_DIR
#define ARD_ADC3_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define CYBSP_A2_HAL_DRIVEMODE ARD_ADC3_HAL_DRIVEMODE
#define sSPI_CLK_HAL_DRIVEMODE ARD_ADC3_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) */

#define ARD_ADC4_ENABLED 1U
#define CYBSP_A3_ENABLED ARD_ADC4_ENABLED
#define sSPI_CS_ENABLED ARD_ADC4_ENABLED
#define ARD_ADC4_PORT GPIO_PRT2
#define CYBSP_A3_PORT ARD_ADC4_PORT
#define sSPI_CS_PORT ARD_ADC4_PORT
#define ARD_ADC4_PORT_NUM 2U
#define CYBSP_A3_PORT_NUM ARD_ADC4_PORT_NUM
#define sSPI_CS_PORT_NUM ARD_ADC4_PORT_NUM
#define ARD_ADC4_PIN 3U
#define CYBSP_A3_PIN ARD_ADC4_PIN
#define sSPI_CS_PIN ARD_ADC4_PIN
#define ARD_ADC4_NUM 3U
#define CYBSP_A3_NUM ARD_ADC4_NUM
#define sSPI_CS_NUM ARD_ADC4_NUM
#define ARD_ADC4_DRIVEMODE CY_GPIO_DM_HIGHZ
#define CYBSP_A3_DRIVEMODE ARD_ADC4_DRIVEMODE
#define sSPI_CS_DRIVEMODE ARD_ADC4_DRIVEMODE
#define ARD_ADC4_INIT_DRIVESTATE 1
#define CYBSP_A3_INIT_DRIVESTATE ARD_ADC4_INIT_DRIVESTATE
#define sSPI_CS_INIT_DRIVESTATE ARD_ADC4_INIT_DRIVESTATE
#ifndef ioss_0_port_2_pin_3_HSIOM
    #define ioss_0_port_2_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_ADC4_HSIOM ioss_0_port_2_pin_3_HSIOM
#define CYBSP_A3_HSIOM ARD_ADC4_HSIOM
#define sSPI_CS_HSIOM ARD_ADC4_HSIOM
#define ARD_ADC4_IRQ ioss_interrupts_gpio_2_IRQn
#define CYBSP_A3_IRQ ARD_ADC4_IRQ
#define sSPI_CS_IRQ ARD_ADC4_IRQ

#if defined (CY_USING_HAL)
#define ARD_ADC4_HAL_PORT_PIN P2_3
#define CYBSP_A3_HAL_PORT_PIN ARD_ADC4_HAL_PORT_PIN
#define sSPI_CS_HAL_PORT_PIN ARD_ADC4_HAL_PORT_PIN
#define ARD_ADC4 P2_3
#define CYBSP_A3 ARD_ADC4
#define sSPI_CS ARD_ADC4
#define ARD_ADC4_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_A3_HAL_IRQ ARD_ADC4_HAL_IRQ
#define sSPI_CS_HAL_IRQ ARD_ADC4_HAL_IRQ
#define ARD_ADC4_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_A3_HAL_DIR ARD_ADC4_HAL_DIR
#define sSPI_CS_HAL_DIR ARD_ADC4_HAL_DIR
#define ARD_ADC4_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define CYBSP_A3_HAL_DRIVEMODE ARD_ADC4_HAL_DRIVEMODE
#define sSPI_CS_HAL_DRIVEMODE ARD_ADC4_HAL_DRIVEMODE
#define ARD_ADC5 (P2_4)
#define CYBSP_A4 ARD_ADC5
#define ARD_ADC6 (P2_5)
#define CYBSP_A5 ARD_ADC6
#define CYBSP_A6 (P2_6)
#define CYBSP_A7 (P2_7)
#define ARD_IO7 CYBSP_A7
#endif /* defined (CY_USING_HAL) */

#define ARD_UART_RX_ENABLED 1U
#define sSPI_MOSI_ENABLED ARD_UART_RX_ENABLED
#define ARD_UART_RX_PORT GPIO_PRT3
#define sSPI_MOSI_PORT ARD_UART_RX_PORT
#define ARD_UART_RX_PORT_NUM 3U
#define sSPI_MOSI_PORT_NUM ARD_UART_RX_PORT_NUM
#define ARD_UART_RX_PIN 0U
#define sSPI_MOSI_PIN ARD_UART_RX_PIN
#define ARD_UART_RX_NUM 0U
#define sSPI_MOSI_NUM ARD_UART_RX_NUM
#define ARD_UART_RX_DRIVEMODE CY_GPIO_DM_HIGHZ
#define sSPI_MOSI_DRIVEMODE ARD_UART_RX_DRIVEMODE
#define ARD_UART_RX_INIT_DRIVESTATE 1
#define sSPI_MOSI_INIT_DRIVESTATE ARD_UART_RX_INIT_DRIVESTATE
#ifndef ioss_0_port_3_pin_0_HSIOM
    #define ioss_0_port_3_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_UART_RX_HSIOM ioss_0_port_3_pin_0_HSIOM
#define sSPI_MOSI_HSIOM ARD_UART_RX_HSIOM
#define ARD_UART_RX_IRQ ioss_interrupts_gpio_3_IRQn
#define sSPI_MOSI_IRQ ARD_UART_RX_IRQ

#if defined (CY_USING_HAL)
#define ARD_UART_RX_HAL_PORT_PIN P3_0
#define sSPI_MOSI_HAL_PORT_PIN ARD_UART_RX_HAL_PORT_PIN
#define ARD_UART_RX P3_0
#define sSPI_MOSI ARD_UART_RX
#define ARD_UART_RX_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define sSPI_MOSI_HAL_IRQ ARD_UART_RX_HAL_IRQ
#define ARD_UART_RX_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define sSPI_MOSI_HAL_DIR ARD_UART_RX_HAL_DIR
#define ARD_UART_RX_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define sSPI_MOSI_HAL_DRIVEMODE ARD_UART_RX_HAL_DRIVEMODE
#define ARD_UART_TX (P3_1)
#endif /* defined (CY_USING_HAL) */

#define SWDIO_ENABLED 1U
#define CYBSP_SWDIO_ENABLED SWDIO_ENABLED
#define SWDIO_PORT GPIO_PRT3
#define CYBSP_SWDIO_PORT SWDIO_PORT
#define SWDIO_PORT_NUM 3U
#define CYBSP_SWDIO_PORT_NUM SWDIO_PORT_NUM
#define SWDIO_PIN 2U
#define CYBSP_SWDIO_PIN SWDIO_PIN
#define SWDIO_NUM 2U
#define CYBSP_SWDIO_NUM SWDIO_NUM
#define SWDIO_DRIVEMODE CY_GPIO_DM_STRONG
#define CYBSP_SWDIO_DRIVEMODE SWDIO_DRIVEMODE
#define SWDIO_INIT_DRIVESTATE 1
#define CYBSP_SWDIO_INIT_DRIVESTATE SWDIO_INIT_DRIVESTATE
#ifndef ioss_0_port_3_pin_2_HSIOM
    #define ioss_0_port_3_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define SWDIO_HSIOM ioss_0_port_3_pin_2_HSIOM
#define CYBSP_SWDIO_HSIOM SWDIO_HSIOM
#define SWDIO_IRQ ioss_interrupts_gpio_3_IRQn
#define CYBSP_SWDIO_IRQ SWDIO_IRQ

#if defined (CY_USING_HAL)
#define SWDIO_HAL_PORT_PIN P3_2
#define CYBSP_SWDIO_HAL_PORT_PIN SWDIO_HAL_PORT_PIN
#define SWDIO P3_2
#define CYBSP_SWDIO SWDIO
#define SWDIO_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_SWDIO_HAL_IRQ SWDIO_HAL_IRQ
#define SWDIO_HAL_DIR CYHAL_GPIO_DIR_BIDIRECTIONAL 
#define CYBSP_SWDIO_HAL_DIR SWDIO_HAL_DIR
#define SWDIO_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_SWDIO_HAL_DRIVEMODE SWDIO_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) */

#define SWCLK_ENABLED 1U
#define CYBSP_SWCLK_ENABLED SWCLK_ENABLED
#define SWCLK_PORT GPIO_PRT3
#define CYBSP_SWCLK_PORT SWCLK_PORT
#define SWCLK_PORT_NUM 3U
#define CYBSP_SWCLK_PORT_NUM SWCLK_PORT_NUM
#define SWCLK_PIN 3U
#define CYBSP_SWCLK_PIN SWCLK_PIN
#define SWCLK_NUM 3U
#define CYBSP_SWCLK_NUM SWCLK_NUM
#define SWCLK_DRIVEMODE CY_GPIO_DM_STRONG
#define CYBSP_SWCLK_DRIVEMODE SWCLK_DRIVEMODE
#define SWCLK_INIT_DRIVESTATE 1
#define CYBSP_SWCLK_INIT_DRIVESTATE SWCLK_INIT_DRIVESTATE
#ifndef ioss_0_port_3_pin_3_HSIOM
    #define ioss_0_port_3_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define SWCLK_HSIOM ioss_0_port_3_pin_3_HSIOM
#define CYBSP_SWCLK_HSIOM SWCLK_HSIOM
#define SWCLK_IRQ ioss_interrupts_gpio_3_IRQn
#define CYBSP_SWCLK_IRQ SWCLK_IRQ

#if defined (CY_USING_HAL)
#define SWCLK_HAL_PORT_PIN P3_3
#define CYBSP_SWCLK_HAL_PORT_PIN SWCLK_HAL_PORT_PIN
#define SWCLK P3_3
#define CYBSP_SWCLK SWCLK
#define SWCLK_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_SWCLK_HAL_IRQ SWCLK_HAL_IRQ
#define SWCLK_HAL_DIR CYHAL_GPIO_DIR_BIDIRECTIONAL 
#define CYBSP_SWCLK_HAL_DIR SWCLK_HAL_DIR
#define SWCLK_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_SWCLK_HAL_DRIVEMODE SWCLK_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) */

#define CMOD1_ENABLED 1U
#define CMOD1_PORT GPIO_PRT5
#define CMOD1_PORT_NUM 5U
#define CMOD1_PIN 1U
#define CMOD1_NUM 1U
#define CMOD1_DRIVEMODE CY_GPIO_DM_ANALOG
#define CMOD1_INIT_DRIVESTATE 1
#ifndef ioss_0_port_5_pin_1_HSIOM
    #define ioss_0_port_5_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define CMOD1_HSIOM ioss_0_port_5_pin_1_HSIOM
#define CMOD1_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define CMOD1_HAL_PORT_PIN P5_1
#define CMOD1 P5_1
#define CMOD1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CMOD1_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CMOD1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define CMOD2_ENABLED 1U
#define CMOD2_PORT GPIO_PRT5
#define CMOD2_PORT_NUM 5U
#define CMOD2_PIN 2U
#define CMOD2_NUM 2U
#define CMOD2_DRIVEMODE CY_GPIO_DM_ANALOG
#define CMOD2_INIT_DRIVESTATE 1
#ifndef ioss_0_port_5_pin_2_HSIOM
    #define ioss_0_port_5_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define CMOD2_HSIOM ioss_0_port_5_pin_2_HSIOM
#define CMOD2_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define CMOD2_HAL_PORT_PIN P5_2
#define CMOD2 P5_2
#define CMOD2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CMOD2_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CMOD2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define CSTX1_ENABLED 1U
#define CSTX1_PORT GPIO_PRT5
#define CSTX1_PORT_NUM 5U
#define CSTX1_PIN 3U
#define CSTX1_NUM 3U
#define CSTX1_DRIVEMODE CY_GPIO_DM_ANALOG
#define CSTX1_INIT_DRIVESTATE 1
#ifndef ioss_0_port_5_pin_3_HSIOM
    #define ioss_0_port_5_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define CSTX1_HSIOM ioss_0_port_5_pin_3_HSIOM
#define CSTX1_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define CSTX1_HAL_PORT_PIN P5_3
#define CSTX1 P5_3
#define CSTX1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CSTX1_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CSTX1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define CSTX2_ENABLED 1U
#define CSTX2_PORT GPIO_PRT5
#define CSTX2_PORT_NUM 5U
#define CSTX2_PIN 4U
#define CSTX2_NUM 4U
#define CSTX2_DRIVEMODE CY_GPIO_DM_ANALOG
#define CSTX2_INIT_DRIVESTATE 1
#ifndef ioss_0_port_5_pin_4_HSIOM
    #define ioss_0_port_5_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define CSTX2_HSIOM ioss_0_port_5_pin_4_HSIOM
#define CSTX2_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define CSTX2_HAL_PORT_PIN P5_4
#define CSTX2 P5_4
#define CSTX2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CSTX2_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CSTX2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define CSTX3_ENABLED 1U
#define CSTX3_PORT GPIO_PRT5
#define CSTX3_PORT_NUM 5U
#define CSTX3_PIN 5U
#define CSTX3_NUM 5U
#define CSTX3_DRIVEMODE CY_GPIO_DM_ANALOG
#define CSTX3_INIT_DRIVESTATE 1
#ifndef ioss_0_port_5_pin_5_HSIOM
    #define ioss_0_port_5_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define CSTX3_HSIOM ioss_0_port_5_pin_5_HSIOM
#define CSTX3_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define CSTX3_HAL_PORT_PIN P5_5
#define CSTX3 P5_5
#define CSTX3_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CSTX3_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CSTX3_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) */

#define CSRX_ENABLED 1U
#define CSRX_PORT GPIO_PRT5
#define CSRX_PORT_NUM 5U
#define CSRX_PIN 6U
#define CSRX_NUM 6U
#define CSRX_DRIVEMODE CY_GPIO_DM_ANALOG
#define CSRX_INIT_DRIVESTATE 1
#ifndef ioss_0_port_5_pin_6_HSIOM
    #define ioss_0_port_5_pin_6_HSIOM HSIOM_SEL_GPIO
#endif
#define CSRX_HSIOM ioss_0_port_5_pin_6_HSIOM
#define CSRX_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define CSRX_HAL_PORT_PIN P5_6
#define CSRX P5_6
#define CSRX_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CSRX_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CSRX_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#define INT_SBC (P5_7)
#endif /* defined (CY_USING_HAL) */

#define USER_LED_RED_ENABLED 1U
#define CYBSP_USER_LED2_ENABLED USER_LED_RED_ENABLED
#define CYBSP_LED_RGB_RED_ENABLED USER_LED_RED_ENABLED
#define USER_LED_RED_PORT GPIO_PRT6
#define CYBSP_USER_LED2_PORT USER_LED_RED_PORT
#define CYBSP_LED_RGB_RED_PORT USER_LED_RED_PORT
#define USER_LED_RED_PORT_NUM 6U
#define CYBSP_USER_LED2_PORT_NUM USER_LED_RED_PORT_NUM
#define CYBSP_LED_RGB_RED_PORT_NUM USER_LED_RED_PORT_NUM
#define USER_LED_RED_PIN 0U
#define CYBSP_USER_LED2_PIN USER_LED_RED_PIN
#define CYBSP_LED_RGB_RED_PIN USER_LED_RED_PIN
#define USER_LED_RED_NUM 0U
#define CYBSP_USER_LED2_NUM USER_LED_RED_NUM
#define CYBSP_LED_RGB_RED_NUM USER_LED_RED_NUM
#define USER_LED_RED_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define CYBSP_USER_LED2_DRIVEMODE USER_LED_RED_DRIVEMODE
#define CYBSP_LED_RGB_RED_DRIVEMODE USER_LED_RED_DRIVEMODE
#define USER_LED_RED_INIT_DRIVESTATE 1
#define CYBSP_USER_LED2_INIT_DRIVESTATE USER_LED_RED_INIT_DRIVESTATE
#define CYBSP_LED_RGB_RED_INIT_DRIVESTATE USER_LED_RED_INIT_DRIVESTATE
#ifndef ioss_0_port_6_pin_0_HSIOM
    #define ioss_0_port_6_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define USER_LED_RED_HSIOM ioss_0_port_6_pin_0_HSIOM
#define CYBSP_USER_LED2_HSIOM USER_LED_RED_HSIOM
#define CYBSP_LED_RGB_RED_HSIOM USER_LED_RED_HSIOM
#define USER_LED_RED_IRQ ioss_interrupt_gpio_IRQn
#define CYBSP_USER_LED2_IRQ USER_LED_RED_IRQ
#define CYBSP_LED_RGB_RED_IRQ USER_LED_RED_IRQ

#if defined (CY_USING_HAL)
#define USER_LED_RED_HAL_PORT_PIN P6_0
#define CYBSP_USER_LED2_HAL_PORT_PIN USER_LED_RED_HAL_PORT_PIN
#define CYBSP_LED_RGB_RED_HAL_PORT_PIN USER_LED_RED_HAL_PORT_PIN
#define USER_LED_RED P6_0
#define CYBSP_USER_LED2 USER_LED_RED
#define CYBSP_LED_RGB_RED USER_LED_RED
#define USER_LED_RED_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_USER_LED2_HAL_IRQ USER_LED_RED_HAL_IRQ
#define CYBSP_LED_RGB_RED_HAL_IRQ USER_LED_RED_HAL_IRQ
#define USER_LED_RED_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define CYBSP_USER_LED2_HAL_DIR USER_LED_RED_HAL_DIR
#define CYBSP_LED_RGB_RED_HAL_DIR USER_LED_RED_HAL_DIR
#define USER_LED_RED_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_USER_LED2_HAL_DRIVEMODE USER_LED_RED_HAL_DRIVEMODE
#define CYBSP_LED_RGB_RED_HAL_DRIVEMODE USER_LED_RED_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) */

#define USER_LED_GREEN_ENABLED 1U
#define CYBSP_USER_LED1_ENABLED USER_LED_GREEN_ENABLED
#define CYBSP_LED_RGB_GREEN_ENABLED USER_LED_GREEN_ENABLED
#define USER_LED_GREEN_PORT GPIO_PRT6
#define CYBSP_USER_LED1_PORT USER_LED_GREEN_PORT
#define CYBSP_LED_RGB_GREEN_PORT USER_LED_GREEN_PORT
#define USER_LED_GREEN_PORT_NUM 6U
#define CYBSP_USER_LED1_PORT_NUM USER_LED_GREEN_PORT_NUM
#define CYBSP_LED_RGB_GREEN_PORT_NUM USER_LED_GREEN_PORT_NUM
#define USER_LED_GREEN_PIN 2U
#define CYBSP_USER_LED1_PIN USER_LED_GREEN_PIN
#define CYBSP_LED_RGB_GREEN_PIN USER_LED_GREEN_PIN
#define USER_LED_GREEN_NUM 2U
#define CYBSP_USER_LED1_NUM USER_LED_GREEN_NUM
#define CYBSP_LED_RGB_GREEN_NUM USER_LED_GREEN_NUM
#define USER_LED_GREEN_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define CYBSP_USER_LED1_DRIVEMODE USER_LED_GREEN_DRIVEMODE
#define CYBSP_LED_RGB_GREEN_DRIVEMODE USER_LED_GREEN_DRIVEMODE
#define USER_LED_GREEN_INIT_DRIVESTATE 1
#define CYBSP_USER_LED1_INIT_DRIVESTATE USER_LED_GREEN_INIT_DRIVESTATE
#define CYBSP_LED_RGB_GREEN_INIT_DRIVESTATE USER_LED_GREEN_INIT_DRIVESTATE
#ifndef ioss_0_port_6_pin_2_HSIOM
    #define ioss_0_port_6_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define USER_LED_GREEN_HSIOM ioss_0_port_6_pin_2_HSIOM
#define CYBSP_USER_LED1_HSIOM USER_LED_GREEN_HSIOM
#define CYBSP_LED_RGB_GREEN_HSIOM USER_LED_GREEN_HSIOM
#define USER_LED_GREEN_IRQ ioss_interrupt_gpio_IRQn
#define CYBSP_USER_LED1_IRQ USER_LED_GREEN_IRQ
#define CYBSP_LED_RGB_GREEN_IRQ USER_LED_GREEN_IRQ

#if defined (CY_USING_HAL)
#define USER_LED_GREEN_HAL_PORT_PIN P6_2
#define CYBSP_USER_LED1_HAL_PORT_PIN USER_LED_GREEN_HAL_PORT_PIN
#define CYBSP_LED_RGB_GREEN_HAL_PORT_PIN USER_LED_GREEN_HAL_PORT_PIN
#define USER_LED_GREEN P6_2
#define CYBSP_USER_LED1 USER_LED_GREEN
#define CYBSP_LED_RGB_GREEN USER_LED_GREEN
#define USER_LED_GREEN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_USER_LED1_HAL_IRQ USER_LED_GREEN_HAL_IRQ
#define CYBSP_LED_RGB_GREEN_HAL_IRQ USER_LED_GREEN_HAL_IRQ
#define USER_LED_GREEN_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define CYBSP_USER_LED1_HAL_DIR USER_LED_GREEN_HAL_DIR
#define CYBSP_LED_RGB_GREEN_HAL_DIR USER_LED_GREEN_HAL_DIR
#define USER_LED_GREEN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_USER_LED1_HAL_DRIVEMODE USER_LED_GREEN_HAL_DRIVEMODE
#define CYBSP_LED_RGB_GREEN_HAL_DRIVEMODE USER_LED_GREEN_HAL_DRIVEMODE
#define USER_BUTTON (P6_3)
#define USER_BTN1 USER_BUTTON
#define CYBSP_USER_BTN USER_BUTTON
#define CYBSP_USER_BTN1 USER_BUTTON
#endif /* defined (CY_USING_HAL) */

#define USER_LED_BLUE_ENABLED 1U
#define CYBSP_USER_LED3_ENABLED USER_LED_BLUE_ENABLED
#define CYBSP_LED_RGB_BLUE_ENABLED USER_LED_BLUE_ENABLED
#define USER_LED_BLUE_PORT GPIO_PRT6
#define CYBSP_USER_LED3_PORT USER_LED_BLUE_PORT
#define CYBSP_LED_RGB_BLUE_PORT USER_LED_BLUE_PORT
#define USER_LED_BLUE_PORT_NUM 6U
#define CYBSP_USER_LED3_PORT_NUM USER_LED_BLUE_PORT_NUM
#define CYBSP_LED_RGB_BLUE_PORT_NUM USER_LED_BLUE_PORT_NUM
#define USER_LED_BLUE_PIN 4U
#define CYBSP_USER_LED3_PIN USER_LED_BLUE_PIN
#define CYBSP_LED_RGB_BLUE_PIN USER_LED_BLUE_PIN
#define USER_LED_BLUE_NUM 4U
#define CYBSP_USER_LED3_NUM USER_LED_BLUE_NUM
#define CYBSP_LED_RGB_BLUE_NUM USER_LED_BLUE_NUM
#define USER_LED_BLUE_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define CYBSP_USER_LED3_DRIVEMODE USER_LED_BLUE_DRIVEMODE
#define CYBSP_LED_RGB_BLUE_DRIVEMODE USER_LED_BLUE_DRIVEMODE
#define USER_LED_BLUE_INIT_DRIVESTATE 1
#define CYBSP_USER_LED3_INIT_DRIVESTATE USER_LED_BLUE_INIT_DRIVESTATE
#define CYBSP_LED_RGB_BLUE_INIT_DRIVESTATE USER_LED_BLUE_INIT_DRIVESTATE
#ifndef ioss_0_port_6_pin_4_HSIOM
    #define ioss_0_port_6_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define USER_LED_BLUE_HSIOM ioss_0_port_6_pin_4_HSIOM
#define CYBSP_USER_LED3_HSIOM USER_LED_BLUE_HSIOM
#define CYBSP_LED_RGB_BLUE_HSIOM USER_LED_BLUE_HSIOM
#define USER_LED_BLUE_IRQ ioss_interrupt_gpio_IRQn
#define CYBSP_USER_LED3_IRQ USER_LED_BLUE_IRQ
#define CYBSP_LED_RGB_BLUE_IRQ USER_LED_BLUE_IRQ

#if defined (CY_USING_HAL)
#define USER_LED_BLUE_HAL_PORT_PIN P6_4
#define CYBSP_USER_LED3_HAL_PORT_PIN USER_LED_BLUE_HAL_PORT_PIN
#define CYBSP_LED_RGB_BLUE_HAL_PORT_PIN USER_LED_BLUE_HAL_PORT_PIN
#define USER_LED_BLUE P6_4
#define CYBSP_USER_LED3 USER_LED_BLUE
#define CYBSP_LED_RGB_BLUE USER_LED_BLUE
#define USER_LED_BLUE_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_USER_LED3_HAL_IRQ USER_LED_BLUE_HAL_IRQ
#define CYBSP_LED_RGB_BLUE_HAL_IRQ USER_LED_BLUE_HAL_IRQ
#define USER_LED_BLUE_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define CYBSP_USER_LED3_HAL_DIR USER_LED_BLUE_HAL_DIR
#define CYBSP_LED_RGB_BLUE_HAL_DIR USER_LED_BLUE_HAL_DIR
#define USER_LED_BLUE_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_USER_LED3_HAL_DRIVEMODE USER_LED_BLUE_HAL_DRIVEMODE
#define CYBSP_LED_RGB_BLUE_HAL_DRIVEMODE USER_LED_BLUE_HAL_DRIVEMODE
#define ARD_IO1 (P7_0)
#endif /* defined (CY_USING_HAL) */

#define ARD_IO2_ENABLED 1U
#define CS_SW_OUTPUT_ENABLED ARD_IO2_ENABLED
#define ARD_IO2_PORT GPIO_PRT7
#define CS_SW_OUTPUT_PORT ARD_IO2_PORT
#define ARD_IO2_PORT_NUM 7U
#define CS_SW_OUTPUT_PORT_NUM ARD_IO2_PORT_NUM
#define ARD_IO2_PIN 1U
#define CS_SW_OUTPUT_PIN ARD_IO2_PIN
#define ARD_IO2_NUM 1U
#define CS_SW_OUTPUT_NUM ARD_IO2_NUM
#define ARD_IO2_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define CS_SW_OUTPUT_DRIVEMODE ARD_IO2_DRIVEMODE
#define ARD_IO2_INIT_DRIVESTATE 1
#define CS_SW_OUTPUT_INIT_DRIVESTATE ARD_IO2_INIT_DRIVESTATE
#ifndef ioss_0_port_7_pin_1_HSIOM
    #define ioss_0_port_7_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_IO2_HSIOM ioss_0_port_7_pin_1_HSIOM
#define CS_SW_OUTPUT_HSIOM ARD_IO2_HSIOM
#define ARD_IO2_IRQ ioss_interrupt_gpio_IRQn
#define CS_SW_OUTPUT_IRQ ARD_IO2_IRQ

#if defined (CY_USING_HAL)
#define ARD_IO2_HAL_PORT_PIN P7_1
#define CS_SW_OUTPUT_HAL_PORT_PIN ARD_IO2_HAL_PORT_PIN
#define ARD_IO2 P7_1
#define CS_SW_OUTPUT ARD_IO2
#define ARD_IO2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CS_SW_OUTPUT_HAL_IRQ ARD_IO2_HAL_IRQ
#define ARD_IO2_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define CS_SW_OUTPUT_HAL_DIR ARD_IO2_HAL_DIR
#define ARD_IO2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CS_SW_OUTPUT_HAL_DRIVEMODE ARD_IO2_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) */

#define ARD_SPI_MOSI_ENABLED 1U
#define ARD_SPI_MOSI_PORT GPIO_PRT8
#define ARD_SPI_MOSI_PORT_NUM 8U
#define ARD_SPI_MOSI_PIN 0U
#define ARD_SPI_MOSI_NUM 0U
#define ARD_SPI_MOSI_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define ARD_SPI_MOSI_INIT_DRIVESTATE 1
#ifndef ioss_0_port_8_pin_0_HSIOM
    #define ioss_0_port_8_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_SPI_MOSI_HSIOM ioss_0_port_8_pin_0_HSIOM
#define ARD_SPI_MOSI_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define ARD_SPI_MOSI_HAL_PORT_PIN P8_0
#define ARD_SPI_MOSI P8_0
#define ARD_SPI_MOSI_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ARD_SPI_MOSI_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define ARD_SPI_MOSI_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) */

#define ARD_SPI_MISO_ENABLED 1U
#define ARD_SPI_MISO_PORT GPIO_PRT8
#define ARD_SPI_MISO_PORT_NUM 8U
#define ARD_SPI_MISO_PIN 1U
#define ARD_SPI_MISO_NUM 1U
#define ARD_SPI_MISO_DRIVEMODE CY_GPIO_DM_HIGHZ
#define ARD_SPI_MISO_INIT_DRIVESTATE 1
#ifndef ioss_0_port_8_pin_1_HSIOM
    #define ioss_0_port_8_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_SPI_MISO_HSIOM ioss_0_port_8_pin_1_HSIOM
#define ARD_SPI_MISO_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define ARD_SPI_MISO_HAL_PORT_PIN P8_1
#define ARD_SPI_MISO P8_1
#define ARD_SPI_MISO_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ARD_SPI_MISO_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define ARD_SPI_MISO_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#endif /* defined (CY_USING_HAL) */

#define ARD_SPI_SCK_ENABLED 1U
#define ARD_SPI_SCK_PORT GPIO_PRT8
#define ARD_SPI_SCK_PORT_NUM 8U
#define ARD_SPI_SCK_PIN 2U
#define ARD_SPI_SCK_NUM 2U
#define ARD_SPI_SCK_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define ARD_SPI_SCK_INIT_DRIVESTATE 1
#ifndef ioss_0_port_8_pin_2_HSIOM
    #define ioss_0_port_8_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define ARD_SPI_SCK_HSIOM ioss_0_port_8_pin_2_HSIOM
#define ARD_SPI_SCK_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define ARD_SPI_SCK_HAL_PORT_PIN P8_2
#define ARD_SPI_SCK P8_2
#define ARD_SPI_SCK_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ARD_SPI_SCK_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define ARD_SPI_SCK_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) */

#define SPI_CS_ENABLED 1U
#define SPI_CS_PORT GPIO_PRT8
#define SPI_CS_PORT_NUM 8U
#define SPI_CS_PIN 3U
#define SPI_CS_NUM 3U
#define SPI_CS_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define SPI_CS_INIT_DRIVESTATE 1
#ifndef ioss_0_port_8_pin_3_HSIOM
    #define ioss_0_port_8_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define SPI_CS_HSIOM ioss_0_port_8_pin_3_HSIOM
#define SPI_CS_IRQ ioss_interrupt_gpio_IRQn

#if defined (CY_USING_HAL)
#define SPI_CS_HAL_PORT_PIN P8_3
#define SPI_CS P8_3
#define SPI_CS_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define SPI_CS_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define SPI_CS_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t WCO_IN_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t WCO_IN_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t WCO_OUT_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t WCO_OUT_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ECO_IN_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ECO_IN_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ECO_OUT_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ECO_OUT_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t KITPROG_RX_config;

#define CYBSP_DEBUG_UART_RX_config KITPROG_RX_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t KITPROG_RX_obj;
#define CYBSP_DEBUG_UART_RX_obj KITPROG_RX_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t KITPROG_TX_config;

#define CYBSP_DEBUG_UART_TX_config KITPROG_TX_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t KITPROG_TX_obj;
#define CYBSP_DEBUG_UART_TX_obj KITPROG_TX_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_ADC3_config;

#define CYBSP_A2_config ARD_ADC3_config
#define sSPI_CLK_config ARD_ADC3_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_ADC3_obj;
#define CYBSP_A2_obj ARD_ADC3_obj
#define sSPI_CLK_obj ARD_ADC3_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_ADC4_config;

#define CYBSP_A3_config ARD_ADC4_config
#define sSPI_CS_config ARD_ADC4_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_ADC4_obj;
#define CYBSP_A3_obj ARD_ADC4_obj
#define sSPI_CS_obj ARD_ADC4_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_UART_RX_config;

#define sSPI_MOSI_config ARD_UART_RX_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_UART_RX_obj;
#define sSPI_MOSI_obj ARD_UART_RX_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t SWDIO_config;

#define CYBSP_SWDIO_config SWDIO_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t SWDIO_obj;
#define CYBSP_SWDIO_obj SWDIO_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t SWCLK_config;

#define CYBSP_SWCLK_config SWCLK_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t SWCLK_obj;
#define CYBSP_SWCLK_obj SWCLK_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t CMOD1_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CMOD1_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t CMOD2_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CMOD2_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t CSTX1_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CSTX1_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t CSTX2_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CSTX2_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t CSTX3_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CSTX3_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t CSRX_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CSRX_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t USER_LED_RED_config;

#define CYBSP_USER_LED2_config USER_LED_RED_config
#define CYBSP_LED_RGB_RED_config USER_LED_RED_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t USER_LED_RED_obj;
#define CYBSP_USER_LED2_obj USER_LED_RED_obj
#define CYBSP_LED_RGB_RED_obj USER_LED_RED_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t USER_LED_GREEN_config;

#define CYBSP_USER_LED1_config USER_LED_GREEN_config
#define CYBSP_LED_RGB_GREEN_config USER_LED_GREEN_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t USER_LED_GREEN_obj;
#define CYBSP_USER_LED1_obj USER_LED_GREEN_obj
#define CYBSP_LED_RGB_GREEN_obj USER_LED_GREEN_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t USER_LED_BLUE_config;

#define CYBSP_USER_LED3_config USER_LED_BLUE_config
#define CYBSP_LED_RGB_BLUE_config USER_LED_BLUE_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t USER_LED_BLUE_obj;
#define CYBSP_USER_LED3_obj USER_LED_BLUE_obj
#define CYBSP_LED_RGB_BLUE_obj USER_LED_BLUE_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_IO2_config;

#define CS_SW_OUTPUT_config ARD_IO2_config

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_IO2_obj;
#define CS_SW_OUTPUT_obj ARD_IO2_obj
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_SPI_MOSI_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_SPI_MOSI_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_SPI_MISO_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_SPI_MISO_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t ARD_SPI_SCK_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t ARD_SPI_SCK_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_gpio_pin_config_t SPI_CS_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t SPI_CS_obj;
#endif /* defined (CY_USING_HAL) */

void init_cycfg_pins(void);
void reserve_cycfg_pins(void);

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_PINS_H */
