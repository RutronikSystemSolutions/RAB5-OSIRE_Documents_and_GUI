/*******************************************************************************
 * File Name: cycfg_pins.c
 *
 * Description:
 * Pin configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.20.0
 * device-db 4.16.0.6098
 * mtb-pdl-cat2 2.11.0.12518
 *
 *******************************************************************************
 * Copyright 2024 Cypress Semiconductor Corporation (an Infineon company) or
 * an affiliate of Cypress Semiconductor Corporation.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#include "cycfg_pins.h"

const cy_stc_gpio_pin_config_t WCO_IN_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = WCO_IN_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t WCO_IN_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = WCO_IN_PORT_NUM,
    .channel_num = WCO_IN_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t WCO_OUT_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = WCO_OUT_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t WCO_OUT_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = WCO_OUT_PORT_NUM,
    .channel_num = WCO_OUT_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ECO_IN_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = ECO_IN_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ECO_IN_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ECO_IN_PORT_NUM,
    .channel_num = ECO_IN_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ECO_OUT_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = ECO_OUT_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ECO_OUT_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ECO_OUT_PORT_NUM,
    .channel_num = ECO_OUT_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t KITPROG_RX_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = KITPROG_RX_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t KITPROG_RX_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = KITPROG_RX_PORT_NUM,
    .channel_num = KITPROG_RX_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t KITPROG_TX_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = KITPROG_TX_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t KITPROG_TX_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = KITPROG_TX_PORT_NUM,
    .channel_num = KITPROG_TX_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_ADC3_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = ARD_ADC3_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_ADC3_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_ADC3_PORT_NUM,
    .channel_num = ARD_ADC3_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_ADC4_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = ARD_ADC4_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_ADC4_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_ADC4_PORT_NUM,
    .channel_num = ARD_ADC4_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_UART_RX_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = ARD_UART_RX_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_UART_RX_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_UART_RX_PORT_NUM,
    .channel_num = ARD_UART_RX_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t SWDIO_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG,
    .hsiom = SWDIO_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t SWDIO_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = SWDIO_PORT_NUM,
    .channel_num = SWDIO_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t SWCLK_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG,
    .hsiom = SWCLK_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t SWCLK_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = SWCLK_PORT_NUM,
    .channel_num = SWCLK_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t CMOD1_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CMOD1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t CMOD1_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = CMOD1_PORT_NUM,
    .channel_num = CMOD1_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t CMOD2_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CMOD2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t CMOD2_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = CMOD2_PORT_NUM,
    .channel_num = CMOD2_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t CSTX1_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CSTX1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t CSTX1_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = CSTX1_PORT_NUM,
    .channel_num = CSTX1_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t CSTX2_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CSTX2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t CSTX2_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = CSTX2_PORT_NUM,
    .channel_num = CSTX2_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t CSTX3_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CSTX3_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t CSTX3_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = CSTX3_PORT_NUM,
    .channel_num = CSTX3_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t CSRX_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CSRX_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t CSRX_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = CSRX_PORT_NUM,
    .channel_num = CSRX_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t USER_LED_RED_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = USER_LED_RED_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t USER_LED_RED_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = USER_LED_RED_PORT_NUM,
    .channel_num = USER_LED_RED_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t USER_LED_GREEN_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = USER_LED_GREEN_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t USER_LED_GREEN_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = USER_LED_GREEN_PORT_NUM,
    .channel_num = USER_LED_GREEN_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t USER_LED_BLUE_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = USER_LED_BLUE_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t USER_LED_BLUE_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = USER_LED_BLUE_PORT_NUM,
    .channel_num = USER_LED_BLUE_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_IO2_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = ARD_IO2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_IO2_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_IO2_PORT_NUM,
    .channel_num = ARD_IO2_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_SPI_MOSI_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = ARD_SPI_MOSI_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_SPI_MOSI_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_SPI_MOSI_PORT_NUM,
    .channel_num = ARD_SPI_MOSI_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_SPI_MISO_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = ARD_SPI_MISO_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_SPI_MISO_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_SPI_MISO_PORT_NUM,
    .channel_num = ARD_SPI_MISO_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t ARD_SPI_SCK_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = ARD_SPI_SCK_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t ARD_SPI_SCK_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = ARD_SPI_SCK_PORT_NUM,
    .channel_num = ARD_SPI_SCK_PIN,
};
#endif /* defined (CY_USING_HAL) */

const cy_stc_gpio_pin_config_t SPI_CS_config =
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = SPI_CS_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
};

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t SPI_CS_obj =
{
    .type = CYHAL_RSC_GPIO,
    .block_num = SPI_CS_PORT_NUM,
    .channel_num = SPI_CS_PIN,
};
#endif /* defined (CY_USING_HAL) */

void init_cycfg_pins(void)
{
    Cy_GPIO_Pin_Init(WCO_IN_PORT, WCO_IN_PIN, &WCO_IN_config);
    Cy_GPIO_Pin_Init(WCO_OUT_PORT, WCO_OUT_PIN, &WCO_OUT_config);
    Cy_GPIO_Pin_Init(KITPROG_RX_PORT, KITPROG_RX_PIN, &KITPROG_RX_config);
    Cy_GPIO_Pin_Init(KITPROG_TX_PORT, KITPROG_TX_PIN, &KITPROG_TX_config);
    Cy_GPIO_Pin_Init(ARD_ADC3_PORT, ARD_ADC3_PIN, &ARD_ADC3_config);
    Cy_GPIO_Pin_Init(ARD_ADC4_PORT, ARD_ADC4_PIN, &ARD_ADC4_config);
    Cy_GPIO_Pin_Init(ARD_UART_RX_PORT, ARD_UART_RX_PIN, &ARD_UART_RX_config);
    Cy_GPIO_Pin_Init(SWDIO_PORT, SWDIO_PIN, &SWDIO_config);
    Cy_GPIO_Pin_Init(SWCLK_PORT, SWCLK_PIN, &SWCLK_config);
    Cy_GPIO_Pin_Init(CSTX2_PORT, CSTX2_PIN, &CSTX2_config);
    Cy_GPIO_Pin_Init(USER_LED_RED_PORT, USER_LED_RED_PIN, &USER_LED_RED_config);
    Cy_GPIO_Pin_Init(USER_LED_GREEN_PORT, USER_LED_GREEN_PIN, &USER_LED_GREEN_config);
    Cy_GPIO_Pin_Init(USER_LED_BLUE_PORT, USER_LED_BLUE_PIN, &USER_LED_BLUE_config);
    Cy_GPIO_Pin_Init(ARD_IO2_PORT, ARD_IO2_PIN, &ARD_IO2_config);
    Cy_GPIO_Pin_Init(ARD_SPI_MOSI_PORT, ARD_SPI_MOSI_PIN, &ARD_SPI_MOSI_config);
    Cy_GPIO_Pin_Init(ARD_SPI_MISO_PORT, ARD_SPI_MISO_PIN, &ARD_SPI_MISO_config);
    Cy_GPIO_Pin_Init(ARD_SPI_SCK_PORT, ARD_SPI_SCK_PIN, &ARD_SPI_SCK_config);
    Cy_GPIO_Pin_Init(SPI_CS_PORT, SPI_CS_PIN, &SPI_CS_config);
}
void reserve_cycfg_pins(void)
{
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&WCO_IN_obj);
    cyhal_hwmgr_reserve(&WCO_OUT_obj);
    cyhal_hwmgr_reserve(&ECO_IN_obj);
    cyhal_hwmgr_reserve(&ECO_OUT_obj);
    cyhal_hwmgr_reserve(&KITPROG_RX_obj);
    cyhal_hwmgr_reserve(&KITPROG_TX_obj);
    cyhal_hwmgr_reserve(&ARD_ADC3_obj);
    cyhal_hwmgr_reserve(&ARD_ADC4_obj);
    cyhal_hwmgr_reserve(&ARD_UART_RX_obj);
    cyhal_hwmgr_reserve(&SWDIO_obj);
    cyhal_hwmgr_reserve(&SWCLK_obj);
    cyhal_hwmgr_reserve(&CMOD1_obj);
    cyhal_hwmgr_reserve(&CMOD2_obj);
    cyhal_hwmgr_reserve(&CSTX1_obj);
    cyhal_hwmgr_reserve(&CSTX2_obj);
    cyhal_hwmgr_reserve(&CSTX3_obj);
    cyhal_hwmgr_reserve(&CSRX_obj);
    cyhal_hwmgr_reserve(&USER_LED_RED_obj);
    cyhal_hwmgr_reserve(&USER_LED_GREEN_obj);
    cyhal_hwmgr_reserve(&USER_LED_BLUE_obj);
    cyhal_hwmgr_reserve(&ARD_IO2_obj);
    cyhal_hwmgr_reserve(&ARD_SPI_MOSI_obj);
    cyhal_hwmgr_reserve(&ARD_SPI_MISO_obj);
    cyhal_hwmgr_reserve(&ARD_SPI_SCK_obj);
    cyhal_hwmgr_reserve(&SPI_CS_obj);
#endif /* defined (CY_USING_HAL) */
}
