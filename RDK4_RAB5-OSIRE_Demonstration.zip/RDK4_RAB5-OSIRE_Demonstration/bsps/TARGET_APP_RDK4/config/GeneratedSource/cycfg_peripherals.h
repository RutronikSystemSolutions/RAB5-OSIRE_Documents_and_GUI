/*******************************************************************************
 * File Name: cycfg_peripherals.h
 *
 * Description:
 * Peripheral Hardware Block configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.20.0
 * device-db 4.16.0.6098
 * mtb-pdl-cat2 2.11.0.12518
 *
 *******************************************************************************
 * Copyright 2024 Cypress Semiconductor Corporation (an Infineon company) or
 * an affiliate of Cypress Semiconductor Corporation.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_PERIPHERALS_H)
#define CYCFG_PERIPHERALS_H

#include "cycfg_notices.h"
#include "cy_sysclk.h"
#include "cy_msc.h"
#include "cy_scb_uart.h"
#include "cy_scb_spi.h"

#if defined (CY_USING_HAL)
#include "cyhal_hwmgr.h"
#endif /* defined (CY_USING_HAL) */

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#define CAPSENSE_ENABLED 1U
#define CY_CAPSENSE_CPU_CLK 48000000u
#define CY_CAPSENSE_VDDA_MV 5000u
#define CY_CAPSENSE_PERI_CLK 48000000u
#define CY_CAPSENSE_PERI_DIV_TYPE CY_SYSCLK_DIV_16_BIT
#define CY_CAPSENSE_PERI_DIV_INDEX 2u
#define CY_CAPSENSE_CORE 0u
#define CY_MSC_SAMPLE_NUMBER 1u
#define CY_MSC_CONFIG_NUMBER 0u
#define CY_MSC_SENSE_PAD_NUMBER 16u
#define CY_MSC_CH_NUMBER 2u
#define CY_MSC_SENSE_MODE_NUMBER 3u
#define CY_MSC_LP_AOC_PRESENT 0u
#define CY_MSC_NP_PRESENT 0u
#define CY_MSC_CAP_PAD_NUMBER 4u
#define CY_CAPSENSE_MSC0_EN (0u)
#define CY_CAPSENSE_MSC1_EN (1u)
#define CY_MSC_CHIP_ID 0u
#define CY_MSC_ENABLED_CH_NUMBER 1u
#define CY_MSC_MASTER_CHIP_EN 0u
#define CY_MSC_COMM_CHIP_EN 0u
#define CY_MSC_LITE_CONFIG_EN 0u
#define CY_MSC_CHANNEL_OFFSET 0u
#define CY_CAPSENSE_DMA_CONFIGURED 0u
#define CYBSP_MSC1_ENABLED 1U
#define CY_MSC1_DMAC_BASE_ADDR NULL
#define CY_MSC1_WR_DMA_CH_INDEX 0u
#define CY_MSC1_CHAIN_WR_DMA_CH_INDEX 0u
#define CY_MSC1_RD_DMA_CH_INDEX 0u
#define CY_MSC1_CHAIN_RD_DMA_CH_INDEX 0u
#define CSB1_Rx0_PORT GPIO_PRT5
#define CSB1_Tx_PORT GPIO_PRT5
#define CSB3_Tx_PORT GPIO_PRT5
#define CSB1_Rx0_PIN 6u
#define CSB1_Tx_PIN 3u
#define CSB3_Tx_PIN 5u
#define CSB1_Rx0_PAD MSC1_SPAD0
#define CSB1_Tx_PAD MSC1_SPAD1
#define CSB3_Tx_PAD MSC1_SPAD2
#define CSB1_Rx0_CH_INDEX 1u
#define CSB1_Tx_CH_INDEX 1u
#define CSB3_Tx_CH_INDEX 1u
#define CY_MSC1_Cmod1_PORT GPIO_PRT5
#define CY_MSC1_Cmod1_PIN 1u
#define CY_MSC1_Cmod1_PORT_NUM 5
#define CY_MSC1_Cmod1_PAD MSC1_CMOD1
#define CY_MSC1_Cmod1_CH_INDEX 1u
#define CY_MSC1_Cmod2_PORT GPIO_PRT5
#define CY_MSC1_Cmod2_PIN 2u
#define CY_MSC1_Cmod2_PORT_NUM 5
#define CY_MSC1_Cmod2_PAD MSC1_CMOD2
#define CY_MSC1_Cmod2_CH_INDEX 1u
#define CY_MSC1_HW MSC1
#define CYBSP_MSC1_HW MSC1
#define CY_MSC1_IRQ msc_1_interrupt_IRQn
#define CYBSP_MSC1_IRQ msc_1_interrupt_IRQn
#define KITPROG_UART_ENABLED 1U
#define KITPROG_UART_HW SCB0
#define KITPROG_UART_IRQ scb_0_interrupt_IRQn
#define sSPI_ENABLED 1U
#define sSPI_HW SCB1
#define sSPI_IRQ scb_1_interrupt_IRQn
#define mSPI_ENABLED 1U
#define mSPI_HW SCB3
#define mSPI_IRQ scb_3_interrupt_IRQn

extern cy_stc_msc_context_t cy_msc_1_context;
extern const cy_stc_scb_uart_config_t KITPROG_UART_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t KITPROG_UART_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_scb_spi_config_t sSPI_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t sSPI_obj;
#endif /* defined (CY_USING_HAL) */

extern const cy_stc_scb_spi_config_t mSPI_config;

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t mSPI_obj;
#endif /* defined (CY_USING_HAL) */

void init_cycfg_peripherals(void);
void reserve_cycfg_peripherals(void);

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_PERIPHERALS_H */
